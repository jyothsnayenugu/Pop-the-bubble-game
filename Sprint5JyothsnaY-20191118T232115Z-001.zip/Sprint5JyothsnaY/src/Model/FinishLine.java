package Model;

import java.awt.*;
import java.awt.geom.Line2D;

public class FinishLine extends  GameFigure{

    public final int SIZE=700;
    private final Line2D.Float finishLine;

    public FinishLine(int x, int y) {
        super(x,y);
        finishLine = new Line2D.Float(0,10,SIZE,10);
    }

    @Override
    public void render(Graphics2D g2) {
        g2.setColor(java.awt.Color.RED);
        g2.setStroke(new BasicStroke(5)); // thickness of stroke
        g2.draw(finishLine);

    }


    @Override
    public void update() {
        // N/A
    }

    @Override
    public int getCollisionRadius() {
        return SIZE/2;
    }
}
