package Model;

import Controller.InputEvent;
import Controller.Main;
import Controller.MouseEventListener;
import Controller.observer.Observer;
import Controller.observer.Subject;

import java.awt.*;
import java.awt.geom.Point2D;
import java.util.ArrayList;

import static Controller.Main.gameData;

public class Bubble extends GameFigure implements Subject {

     public  static final int UNIT_MOVE = 5;
    public static final int STATE_IDLE=0;
    public static final int STATE_MOVING=1;
    public static final int STATE_POP=2;
    public  static final int STATE_STUCK=3;
    public  static final int STATE_DONE=4;


   public int size = 50;
   // Point2D.Float target;
  public  BubbleEnemy target;
    public static Color myColor1;
      int state;

   ArrayList<Observer> listeners = new ArrayList<>();

    public  Bubble(int tx, int ty,Color color) {
      //  super(tx,ty);
        Arrow arr = (Arrow) gameData.fixedObject.get(Main.INDEX_SHOOTER);
        super.location.x = arr.arrow.x2;
       super.location.y = arr.arrow.y2;
    //   target = new BubbleEnemy(tx, ty, java.awt.Color.BLUE);
               //new Bubble(tx, ty, java.awt.Color.BLUE); //(Point2D.Float) new BubbleEnemy((int)location.x,(int)location.y,color);
        this.myColor1 = color;
        state = STATE_IDLE;
    }

    @Override
    public void render(Graphics2D g2) {
        g2.setColor(myColor1);
       g2.setStroke(new BasicStroke(1)); // thickness of
        g2.fillOval((int)super.location.x-25,(int)super.location.y ,size,size);
       // g2.draw(bubble);
        g2.getColor();
     //   System.out.println("col is"+g2.getColor());
    }

    @Override

    public void update() {
        updateState();
//      if(state==STATE_IDLE) {
//          MousePointer mousePointer = (MousePointer) Main.gameData.fixedObject.get(Main.INDEX_MOUSE_POINTER);
//
//          float x = mousePointer.location.x;
//          float y = mousePointer.location.y;
//          double rad = Math.atan2(y - super.location.y, x - super.location.x);
//          location.y = (float) (size * Math.sin(rad));
//          location.x = (float) (size * Math.cos(rad));
         if(state==STATE_MOVING) {
        //  for( var be = Main.gameData.enemyObject) {
          var be = Main.gameData.enemyObject.get(13);
//               BubbleEnemy be = (BubbleEnemy) Main.gameData.enemyObject.get(22);
              float tx = be.location.x;
              float ty = be.location.y;
//           double rad = Math.atan2(target.getLocationY() - super.location.y, target.getLocationY() - super.location.x);
              double rad = Math.atan2(be.getLocationY() - super.location.y, be.getLocationY() - super.location.x);
              // System.out.println("playr locdcf");
              location.y += UNIT_MOVE * Math.sin(rad);
              location.x += UNIT_MOVE * Math.cos(rad);
           } else if (state==STATE_DONE) {
           super.done = true;
       }
    }


   private void updateState() {
       if(state == STATE_IDLE) {
          if( InputEvent.mousepress ==true)
           state = STATE_MOVING;
           //       System.out.println("id state");
       }else if (state == STATE_MOVING) {
            if (hitCount > 0   ) { // && Bubble.myColor1 == target.myColor
                state = STATE_POP;
             //   notifyEvent();
//                System.out.println("col is"+g.getColor());
                InputEvent.mousepress=false;
            }
        }else if(state == STATE_POP){
            state = STATE_DONE;
           notifyEvent();

       }else if(state == STATE_DONE){
            super.done = true;
            System.out.println(" done state");

        }
    }


    @Override
    public int getCollisionRadius() {
        return size/2;
    }

    @Override
    public void attachListener(Observer o) {
        listeners.add(o);
    }

    @Override
    public void detachListener(Observer o) {
        listeners.remove(o);
    }

    @Override
    public void notifyEvent() {
        for(var o: listeners){
            o.eventReceived();
        }
    }
}
//  System.out.println("enemy is" +Main.gameData.enemyObject.get(24));
//        System.out.println("enemy is" +be.location.x);
//        System.out.println("enemy is" +be.location.y);
//        System.out.println("enemy COLOUR is" +be.myColor);
//       System.out.println("enemy is" +BubbleEnemy.myColor);
//    System.out.println("bub COLOUR is" +Bubble.myColor1 );