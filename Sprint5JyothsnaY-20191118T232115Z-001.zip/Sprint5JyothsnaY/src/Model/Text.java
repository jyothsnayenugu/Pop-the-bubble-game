package Model;

import Controller.Main;

import java.awt.*;

import static Controller.Main.startScreen;

public class Text extends GameFigure {

    String  text;
    Color color;
    Font font;
    public  static final int STATE_FLYING =0;
    public  static final int STATE_FALLING =1;
    public  static final int STATE_DONE=2;
    int state;
    boolean  movingRight=true;
    public Text(String text, int x , int y, Color color, Font font) {
        super(x,y);
        this.text = text;
        this.color = color;
        this.font = font;
    }
    @Override
    public void render(Graphics2D g2) {
        g2.setColor(color);
        g2.setFont(font);
        g2.drawString(text, (int) location.x, (int) location.y);
    }

    @Override
    public void update() {
        updateState();
        if (location.x >= Main.win.canvas.width) {
                movingRight = false;
        } else if (location.x <= 0) {
               movingRight = true;
        }
    }



    private void updateState() {
        if (state == STATE_FLYING) {
            if (hitCount>0) {
                state = STATE_FALLING;
                // animStrategy = new UFOAnimFalling(this);
            }
        } else if (state == STATE_FALLING) {
            if (location.y >= Main.win.canvas.height) {
                startScreen() ;
                // shw soe msg on canvs
                  /*  Font font = new Font("Courier New", Font.BOLD,40);
                    gameData.friendObject.add(new Text("Press Start", 100,200, Color.YELLOW,font)); */
                state= STATE_DONE; }
        } else if (state == STATE_DONE) {
          //  endScreen();
            super.done = true;

        }
    }

    @Override
    public int getCollisionRadius() {
        return 0;
    }
}
