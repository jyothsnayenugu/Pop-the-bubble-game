package Model;

import Controller.Main;

import java.awt.*;

public class StoneEnemy extends GameFigure {


    public int size=50;
    public  static final int STATE_IDLE =0;
    public  static final int STATE_POP =1;
    public  static final int STATE_DONE=2;
    int state;

    public StoneEnemy(int x, int y){
        super(x,y);

    }
    @Override
    public void render(Graphics2D g2) {
        g2.setColor(java.awt.Color.darkGray);
        g2.setStroke(new BasicStroke(1));
        g2.fillOval((int)super.location.x,(int)super.location.y,size,size);
    }

    @Override
    public void update() {
        updateState();
        if (state == STATE_POP) {
            //  location.y += UNIT_MOVE;
            super.done = true;
        }
    }

    private void updateState() {
        if (hitCount>0) {state = STATE_POP;
            //   if ( hitCount>0  || BubbleEnemy.myColor  == Bubble.myColor1 )  {
            //  state = STATE_POP;
        } else if (state == STATE_POP) {
            if (location.y >= Main.win.canvas.height) {
                state= STATE_DONE; }
        } else if (state == STATE_DONE) {
            super.done = true;
        }
    }

    @Override
    public int getCollisionRadius() {
        return size/2;
    }
}
