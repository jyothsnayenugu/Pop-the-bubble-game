package Model;

import Controller.Main;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class BubbleEnemy extends GameFigure {

    public  static int UNIT_MOVE=5;
       public int size = 50;
      public int width,height;
    public  Color myColor;
    public  static final int STATE_IDLE =0;
    public  static final int STATE_POP =1;
    public  static final int STATE_DONE=2;
    int state;


    public BubbleEnemy(int x, int y, Color color) {
        super(x,y);
        this.myColor = color;
        width= size;
        height=size;
        state=STATE_IDLE;
       }

    @Override
    public void render(Graphics2D g2) {
                g2.setStroke(new BasicStroke(1));
                g2.setColor(myColor);
                g2.fillOval((int) location.x - width, (int) location.y - height, width, height);
                g2.getColor();
       // System.out.println("enemy col is"+g2.getColor());
            }
    @Override
    public void update() {
         updateState();
       if (state == STATE_POP) {
         //  location.y += UNIT_MOVE;
           super.done = true;
        }
    }

    private void updateState() {
//        for(int i=20; i>24;i++){
      //  var be = (BubbleEnemy)Main.gameData.enemyObject.get(13); //&& be.myColor  == Bubble.myColor1
        if (hitCount>0 && this.myColor  == Bubble.myColor1  ) {//&& be.myColor  == Bubble.myColor1

          //  be.state= STATE_POP;
            state = STATE_POP; }
         else if (state == STATE_POP) {
            if (location.y >= Main.win.canvas.height) {
                state= STATE_DONE; }
        } else if (state == STATE_DONE) {
            super.done = true;
        }
}

@Override
    public int getCollisionRadius() { return (size/2 );  }
}
