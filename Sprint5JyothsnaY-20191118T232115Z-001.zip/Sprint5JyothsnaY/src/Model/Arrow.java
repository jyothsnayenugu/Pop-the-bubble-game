package Model;

import Controller.Main;

import java.awt.*;
import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;

public class Arrow extends GameFigure {


    public final  int ARROW_LEN = 50;
    public  static final  int UNIT_MOVE = 10; // pixels
    public  Line2D.Float finishLine;
    public Line2D.Float arrow;
   // int size=50;

    public  Arrow(int x, int y){
        super(x,y);
        arrow = new Line2D.Float(x,y,x,y-ARROW_LEN);
    }

    @Override
    public void render(Graphics2D g2) {

       // BufferedImage bufferedImage =;
        g2.setColor(Color.RED);
        g2.setStroke(new BasicStroke(5)); // thickness of stroke
        g2.draw(arrow);
    }

    @Override
    public void update() {
        MousePointer mousePointer = (MousePointer) Main.gameData.fixedObject.get(Main.INDEX_MOUSE_POINTER);
        float tx= mousePointer.location.x;
        float ty = mousePointer.location.y;
        double rad =Math.atan2(ty - super.location.y, tx- super.location.x);
        float arrow_y = (float)(ARROW_LEN* Math.sin(rad));
        float arrow_x= (float)(ARROW_LEN* Math.cos(rad));

        arrow.x1 = super.location.x;
        arrow.y1 = super.location.y;
        arrow.x2 = super.location.x+arrow_x;
        arrow.y2 = super.location.y+arrow_y;

      //  base.x1 = location.x - BASE_SIZE / 2;
      //  base.y1 = location.y - BASE_SIZE / 2;
    }

    @Override
    public int getCollisionRadius() {
        return 0;
    }
}
