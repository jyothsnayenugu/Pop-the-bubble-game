package Model;

import Controller.InputEvent;
import Controller.Main;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.io.IOException;

public class FireBall extends GameFigure {

    private int size = 50;
      Image image;
    public  static final int UNIT_MOVE = 5;
    public static final int STATE_IDLE=0;
    public static final int STATE_MOVING=1;
    public static final int STATE_POP=2;
    public  static final int STATE_STUCK=3;
    public  static final int STATE_DONE=4;
    int state;

    public FireBall(int x, int y) {
       // super(x, y);
        Arrow arr = (Arrow) Main.gameData.fixedObject.get(Main.INDEX_SHOOTER);
        super.location.x = arr.arrow.x2;
        super.location.y = arr.arrow.y2;
        try {
            this.image = ImageIO.read(getClass().getResource("Fireball.png"));
        }catch (IOException e){
            e.printStackTrace();

        }
     state = STATE_IDLE;
    }


    @Override
    public void render(Graphics2D g2) {
        g2.setColor(Color.yellow);
      //  g2.setStroke(new BasicStroke(1));
//        ImageIcon  image = new ImageIcon("Fireball.png");
        g2.drawImage(this.image,(int)super.location.x-25,(int)super.location.y,size,size,null);
    }
    @Override
    public void update() {
         updateState();
         var be = /*(StoneEnemy)*/ Main.gameData.enemyObject.get(0);
         float tx = be.location.x;
        float ty = be.location.y;

       if(state==STATE_MOVING) {
           double rad = Math.atan2(ty - super.location.y, tx - super.location.x);
           location.y += UNIT_MOVE * Math.sin(rad);
           location.x += UNIT_MOVE * Math.cos(rad);
       }  else if (state==STATE_DONE) {
           super.done = true;
       }
    }


    private void updateState() {
        if(state == STATE_IDLE) {
            if( InputEvent.mousepress ==true)
                state = STATE_MOVING;
            //       System.out.println("id state");
        }else if (state == STATE_MOVING) {
            if (hitCount > 0   ) { // && Bubble.myColor1 == target.myColor
                state = STATE_POP;
                //   notifyEvent();
//                System.out.println("col is"+g.getColor());
                InputEvent.mousepress=false;
            }
        }else if(state == STATE_POP){
            state = STATE_DONE;

        }else if(state == STATE_DONE){
            super.done = true;
            System.out.println(" done state");

        }
    }

    @Override
    public int getCollisionRadius() {
        return size/2;
    }
}
//    private void updateState() {
//        if (state == STATE_IDLE) {
//            if(InputEvent.mousepress==true)
//                state=STATE_MOVING;
//        } else     if (state == STATE_MOVING) {
//            if (hitCount > 0) {//&& be.myColor  == Bubble.myColor1
//                state = STATE_POP;
//                InputEvent.mousepress=false;
//            }
//        } else if (state == STATE_POP) {
//            if (location.y >= Main.win.canvas.height) {
//                state= STATE_DONE; }
//        } else if (state == STATE_DONE) {
//            super.done = true;
//        }
//    }