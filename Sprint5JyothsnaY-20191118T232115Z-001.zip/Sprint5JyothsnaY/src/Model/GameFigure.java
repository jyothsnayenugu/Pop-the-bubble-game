package Model;

import java.awt.*;
import java.awt.geom.Point2D;
import java.util.ArrayList;

public abstract class GameFigure {

    public Color Color;
    public Point2D.Float location;
    public  boolean done = false;
    public  int hitCount =0;


    public GameFigure(float x, float y) {
        location = new Point2D.Float(x,y);
       // this.Color=col;
    }

    public GameFigure() {
        this(0,0);
    }
    public  void setLocation(float x, float y){
        location.x=x;
        location.y=y;
    }
    public  float getLocationX() {
        return location.x;
    }
    public float getLocationY() {
        return location.y;
    }
 /*   public Color getColor() {
        return Color ;
    }
*/
 public boolean colorMatch(GameFigure o){
    // double dist=this.location.distance(o.location);
//     if(dist<= this.getCollisionRadius() + o.getCollisionRadius())
     System.out.println("col mathch ic" +o.Color);
         return (o.Color == Color);

     }
    public boolean collideWith(GameFigure o){
        double dist=this.location.distance(o.location);
        if(dist<= this.getCollisionRadius() + o.getCollisionRadius())
            return true;
        else
            return  false;
    }

    public  abstract void render(Graphics2D g2);
    public  abstract void update();
    public  abstract int getCollisionRadius();
}
