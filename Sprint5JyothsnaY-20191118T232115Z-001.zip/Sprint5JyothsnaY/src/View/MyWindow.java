package View;

import Controller.KeyEventListener;
import Controller.Main;
import Controller.MouseEventListener;

import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;

public class MyWindow extends JFrame {


    public MyCanvas canvas;
    public JButton startButton;
    public void init() {
        setSize(750, 600);
        setLocation(80, 50);
        setTitle(" Pop The Bubbles Game");

           canvas = new MyCanvas();
           MouseEventListener listener = new MouseEventListener();
           canvas.addMouseListener(listener);
           canvas.addMouseMotionListener(listener);

           KeyEventListener keyListener = new KeyEventListener();
           canvas.addKeyListener(keyListener);
           canvas.setFocusable(true);

           var cp = getContentPane();
           cp.add(BorderLayout.CENTER, canvas);

           startButton = new JButton("Play");
           startButton.setFocusable(false);
           JPanel buttonPanel = new JPanel();
           buttonPanel.add(startButton);
           cp.add(BorderLayout.SOUTH, buttonPanel);
           // anynomous class, lambda

           startButton.addActionListener (e->
           {  if(!Main.running) {
              startButton.setText("Quit");
              Main.running = true;
           } else {
           System.exit(0);
           } }
           );

    }
}