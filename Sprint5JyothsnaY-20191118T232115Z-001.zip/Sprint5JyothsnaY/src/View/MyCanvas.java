package View;

import Controller.Main;

import javax.swing.*;
import java.awt.*;

public class MyCanvas extends JPanel {
    public int width;
    public int height;
    public void  render(){
        width = getSize().width;
        height = getSize().height;

        // off screen doble bufr imag
        Image DBI = createImage(width,height);
        if (DBI== null) {
            System.out.println("ERROR: DBL is null");
            System.exit(1);
        }
        // off scree rendering
        Graphics2D g2OffScreen =(Graphics2D) DBI.getGraphics();
        if(g2OffScreen== null) {
            System.out.println("ERROR: g2 screen is null");
            System.exit(1);
        }

        // initilize the image buffer
        g2OffScreen.setBackground(Color.cyan);
        g2OffScreen.clearRect(0,0,width,height);
        // render all game data here
        for (var fig: Main.gameData.fixedObject) {
            fig.render(g2OffScreen);
        }
        for (var fig: Main.gameData.friendObject) {
            fig.render(g2OffScreen);
        }
        for (var fig: Main.gameData.enemyObject) {
            fig.render(g2OffScreen);
        }

        // use active rendering to put the buffer image on screen
        Graphics gOnScreen;
        gOnScreen = this.getGraphics();
        if(gOnScreen != null) {
            gOnScreen.drawImage(DBI, 0, 0, null);
        }
        Toolkit.getDefaultToolkit().sync();
        if(gOnScreen != null) {
            gOnScreen.dispose();
        }

    }

}

