package Controller;


import Controller.observer.BubbleCreateEvent;
import Model.*;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.util.LinkedList;
import static Controller.Main.gameData;

public class PlayerInputEventQueue {

    public LinkedList<InputEvent> queue = new LinkedList<>() ;

    public void processInputEvents() {

        while(!queue.isEmpty()) {
            InputEvent IE = queue.removeFirst();

            switch (IE.type) {
               case InputEvent.MOUSE_PRESSED:

                    MouseEvent e = (MouseEvent) IE.event;
                    InputEvent.mousepress=true;
                    Bubble pe = (Bubble) gameData.friendObject.get(Main.INDEX_BUBBLE);
                    pe.location.x = e.getX();//
                    pe.location.y =e.getY();//
//                   var bub =(BubbleEnemy) gameData.enemyObject.get(24);
//                   Bubble b = new Bubble ((int) bub.getLocationX(), (int)bub.getLocationY() );
                    break;

                case InputEvent.MOUSE_MOVED:
                    MousePointer mp = (MousePointer) gameData.fixedObject.get(0);
                    MouseEvent me  = (MouseEvent) IE.event;
                    mp.location.x = me.getX();
                    mp.location.y =me.getY();
//                    Bubble b1 = (Bubble) gameData.friendObject.get(Main.INDEX_BUBBLE);
//                    b1.location.x = me.getX();
//                    b1.location.y =me.getY();
                    break;

                case InputEvent.MOUSE_DRAGGED:
                   Bubble bb = (Bubble) gameData.friendObject.get(0);
                    MouseEvent mee  = (MouseEvent) IE.event;
                    bb.location.x = mee.getX();
                    bb.location.y =mee.getY();

                    break;

                case InputEvent.BUBBLE_CREATE:
                    BubbleCreateEvent be = (BubbleCreateEvent) IE.event;
                    Main.addBubbleWithListener(be.getX(),be.getY(),be.getColor());
                    break;

                case InputEvent.KEY_PRESSED:
                  //  var fireball = Main.gameData.friendObject.get(Main.INDEX_FIREBALL);
                    KeyEvent ke  = (KeyEvent)IE.event;

                    switch (ke.getKeyCode()){
                        case KeyEvent.VK_UP:
                          //  int x=0,y=0;
                           Arrow arr=(Arrow) Main.gameData.fixedObject.get(Main.INDEX_SHOOTER);
                            FireBall b = new FireBall((int)arr.location.x,(int)arr.location.y);
                            System.out.println("fire ball is created");
                            Main.gameData.friendObject.add(b);
//                            StoneEnemy se = (StoneEnemy) gameData.enemyObject.get(0);
//                            b.location.x =se.getLocationX();
//                            b.location.y =se.getLocationY()+1 ;
                            break;
                    }
                            break;
            }
        }
    }
}
