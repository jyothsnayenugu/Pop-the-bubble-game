package Controller;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class MouseEventListener extends MouseAdapter {

    @Override
    public void  mousePressed(MouseEvent e ){
        //  System.out.println("mouse pressed at " + e.getX() + " " + e.getY());
        InputEvent IE= new InputEvent();
        IE.event=e;
        IE.type=InputEvent.MOUSE_PRESSED;
        Main.PIQ.queue.add(IE);
    }

    @Override
    public void  mouseMoved(MouseEvent e ){

        //System.out.println("mouse moved at " + e.getX() + " " + e.getY());
        InputEvent IE= new InputEvent();
        IE.event=e;
        IE.type=InputEvent.MOUSE_MOVED;
        Main.PIQ.queue.add(IE);
    }

    @Override
    public  void  mouseDragged(MouseEvent e) {
        InputEvent IE= new InputEvent();
        IE.event=e;
        IE.type=InputEvent.MOUSE_PRESSED;
        Main.PIQ.queue.add(IE);
    }
}
