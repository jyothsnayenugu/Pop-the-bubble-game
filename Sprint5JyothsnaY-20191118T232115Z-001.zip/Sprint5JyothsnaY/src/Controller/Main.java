package Controller;

import Controller.observer.BubbleObserverAddNew;
import Model.*;
import View.MyWindow;
import javax.swing.*;
import java.awt.*;
import java.util.Random;

public class Main {


    public  static MyWindow win;
    public  static GameData gameData;
    public static PlayerInputEventQueue PIQ;
    public static boolean running;

    public static int INDEX_MOUSE_POINTER = 0; //
    public static int INDEX_SHOOTER = 1;
    public static final int INDEX_RED_lINE =3 ;
    public static int INDEX_BUBBLE = 1; //
    public static int INDEX_FIREBALL = 2;

    public static int FPS =50;
    public static void main(String[] args) {

        win = new MyWindow();
        win.init();
        win.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        win.setVisible(true);
        gameData = new GameData();
        PIQ = new PlayerInputEventQueue();
        startScreen();
        initGame();
        gameLoop();
    }
    public static void startScreen() {
        // shw soe msg on canvs
        Font font = new Font("Courier New", Font.ITALIC,40);
        gameData.friendObject.add(new Text("Pop The Bubbles", 200,200, Color.MAGENTA,font));
        while(!running) {
            Main.win.canvas.render();
            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        // fininsh wen rng= tru
    }
    static void initGame() {
        gameData.fixedObject.add(new MousePointer(0,0));
        int x = Main.win.getWidth() / 2;
        int y = Main.win.getHeight() - 100;
       //adding the arrow thing here
         gameData.fixedObject.add(new Arrow(x, y));
         gameData.fixedObject.add(new FinishLine(0, 10));
         addBubbleWithListener(350, 650,Color.blue);
//         gameData.friendObject.add(new FireBall(350, 650 ));
        for (int a=50; a<=600;a+=50) {
            gameData.enemyObject.add(new StoneEnemy(a, 10)); }
        //adding enenybubble shere
        Color[] colors = {Color.green,Color.MAGENTA,Color.pink, Color.RED,Color.BLUE };
        Random r1=new Random();
         for (int i = 150; i <= 600; i+=50) {
             for (int j = 110; j <= 260; j += 50) {
                 gameData.enemyObject.add(new BubbleEnemy(i, j, colors[r1.nextInt(5)]));  //[(j/50)-1]
             }
         }
      //  System.out.println("enemy is"+gameData.enemyObject.indexOf(gameData.enemyObject ));
    }


     public static void addBubbleWithListener(int x, int y,Color col) {
        var bub = new Bubble(x,y,col);
        bub.attachListener(new BubbleObserverAddNew());
        gameData.friendObject.add(bub);
    }
    static void gameLoop() {
        running= true;
        // game loop
        while(running) {
            long startTime = System.currentTimeMillis();

            PIQ.processInputEvents();
            processCollisions();
         //   processMatch();
            gameData.update();
            win.canvas.render();
            long endTime = System.currentTimeMillis();

            long timeSpent = endTime-startTime;
            long sleepTime=(long)(1000.0/FPS - timeSpent);

            try {
                if(sleepTime > 0) Thread.sleep(sleepTime);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

    }



    static void processCollisions() {

        for (var friend : Main.gameData.friendObject) {
            for (var enemy: Main.gameData.enemyObject){
                if (friend.collideWith(enemy)) {
                    ++friend.hitCount;
                    ++enemy.hitCount;
                }
            }
        }
     //   for (var enemy : Main.gameData.friendObject) {
//            for (var enemy: Main.gameData.enemyObject){
//                if (enemy.collideWith(enemy)) {
//                   // ++friend.hitCount;
//                    ++enemy.hitCount;
//                }
//            }
//
    }

}