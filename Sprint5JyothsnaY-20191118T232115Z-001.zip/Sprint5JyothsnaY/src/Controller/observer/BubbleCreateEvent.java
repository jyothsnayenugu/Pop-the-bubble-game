package Controller.observer;

import java.awt.*;
import java.util.EventObject;

public class BubbleCreateEvent extends EventObject {

    private  int x;
    private  int y;
    private Color color;
    /**
     * Constructs a prototypical Event.
     *
     * @param source the object on which the Event initially occurred
     * @throws IllegalArgumentException if source is null
     */
    public BubbleCreateEvent(Object source, int x, int y, Color color) {
        super(source);
        this.x = x;
        this.y=y;
        this.color=color;
    }
    public int getX() {return x;}
    public int getY() {return y;}
    public Color getColor() {return  color;}
}
