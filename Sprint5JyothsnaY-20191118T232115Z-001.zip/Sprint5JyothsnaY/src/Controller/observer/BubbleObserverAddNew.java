package Controller.observer;


import Controller.InputEvent;
import Controller.Main;
import Model.Bubble;

import java.awt.*;

public class BubbleObserverAddNew    implements Observer  {
public static int i=0;
   Color[] col = { Color.RED,Color.pink,Color.MAGENTA,Color.green,Color.blue};
    @Override
    public void eventReceived() {
        InputEvent event= new InputEvent();
//        for(i=0;i>=col.length;i++) {
            event.event = new BubbleCreateEvent("Bubble", 350, 650, col[i%5]);
            event.type = InputEvent.BUBBLE_CREATE;
            Main.PIQ.queue.add(event);
            i++;
//        for(var bub : Main.PIQ.queue){
//            i++; }

    }

}


